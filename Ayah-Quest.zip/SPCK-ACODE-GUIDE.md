# Ayah Quest for Spck Editor & Acode (Android)

## How to use in Spck Editor:
1. Open Spck Editor on your Android phone.
2. Tap the "+" (or Hamburger menu) -> "Import Project" -> "From ZIP".
3. Select this `Ayah-Quest.zip` file.
4. Spck will immediately recognize the project with `index.html` at root!
5. Tap the green Play button (▶) to run the live preview directly on your phone.
6. To push to GitHub from Spck:
   - Tap the Git branch icon in Spck.
   - Add your GitHub repository URL.
   - Commit & Push!

## How to use in Acode:
1. Open Acode on your Android phone.
2. In the sidebar, tap "Open Folder" or extract `Ayah-Quest.zip`.
3. Open `index.html`.
4. Tap the Play icon (▶) in Acode to run in browser preview!

## Project Structure:
- `index.html` & `assets/`: Instant offline & online preview without needing Node on Android.
- `src/`: Complete React 19 + TypeScript + Tailwind source code.
- `worker/`: Cloudflare Worker & Telegram Bot backend.
- `supabase/`: Database schema for Supabase (profiles, SRS logs, Telebirr payments).
- `standalone-html/`: Pure HTML/JS/Tailwind variant.
- `package.json` & `vite.config.ts`: Ready for Vercel, Netlify, Cloudflare Pages, or Termux.
